package com.ictech.dpatterns;

public interface ComplexNameInterface {
    public void setfname(String fname);
    public String getfname();
    public void setlname(String lname);
    public String getlname();
}
