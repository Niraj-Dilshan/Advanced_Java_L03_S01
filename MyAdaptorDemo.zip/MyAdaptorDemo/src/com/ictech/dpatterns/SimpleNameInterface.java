package com.ictech.dpatterns;

public interface SimpleNameInterface {
    public void setname(String name);
    public String getname();
}
