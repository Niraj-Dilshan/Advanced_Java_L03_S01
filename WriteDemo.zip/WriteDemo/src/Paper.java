public class Paper {

}
