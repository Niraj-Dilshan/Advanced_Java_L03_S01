package com.ictech.dpatterns;

public interface Shape {
    void draw();
}
