public class FileHandlingRecapDemo {
    public static void main(String[] args) {
        //Write to the file
        MyFileWriter mfw = new MyFileWriter();
        mfw.writeToMyFile();

        //Read from the file
        MyFileReader mfr = new MyFileReader();
        mfr.readFromMyFile();
    }
}
