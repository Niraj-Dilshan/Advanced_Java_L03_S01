package com.ictec.dpatterns;

public interface MyObserver {
    public void update(String msg);//Enabling getting notification | The method to call when a notification ready
}
