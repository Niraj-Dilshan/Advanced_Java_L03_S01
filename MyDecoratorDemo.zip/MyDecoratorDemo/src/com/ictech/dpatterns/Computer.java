package com.ictech.dpatterns;

public class Computer {
    public Computer() {

    }

    public String description(){
        return "Computer";
    }
}
