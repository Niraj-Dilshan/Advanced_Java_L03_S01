package com.ictech.dpatterns;

public class ComDVD extends ComputerDecorator{
    Computer dvdCom;
    public ComDVD(Computer com) {
        dvdCom = com;
    }

    @Override
    public String description() {
        return dvdCom.description()+" And A DVD";
    }
}
