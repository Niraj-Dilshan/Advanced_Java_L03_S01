package com.ictech.dpatterns;

public abstract class ComputerDecorator extends Computer{
    public abstract String description();



}
