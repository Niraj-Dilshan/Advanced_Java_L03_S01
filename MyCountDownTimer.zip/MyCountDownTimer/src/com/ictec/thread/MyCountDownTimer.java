package com.ictec.thread;

public class MyCountDownTimer {
    public static void main(String[] args) {
        MyThread th1 = new MyThread();
        th1.start();
    }
}
